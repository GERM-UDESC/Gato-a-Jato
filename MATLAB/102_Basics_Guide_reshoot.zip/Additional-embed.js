   function SwitchPlayer( elementId, styleId, VideoHeight, PIPAndVideoWidth, MediaDirectory, ConfigMediaDirectory, FlashController, FlashConfig, FlashQuality, SWFMinPlayerVersion, SWFBGColor, SWFLoadingMovURL, SWFMatchPreloadMovieSize )
   {        
      var MediaDirAndController = MediaDirectory + FlashController;
      var MedaiDirAndConfig     = ConfigMediaDirectory + FlashConfig;
      var BGColor = "#" + SWFBGColor;
      
      var fo = new SWFObject( MediaDirAndController, FlashController, PIPAndVideoWidth, VideoHeight, SWFMinPlayerVersion, BGColor, false, FlashQuality );
      fo.addVariable( "csConfigFile", MedaiDirAndConfig ); 
      fo.addVariable( "csColor"     , SWFBGColor        );
      
      if( SWFLoadingMovURL != "" && SWFLoadingMovURL != null )
      {
         fo.addVariable( "csPreloader" , SWFLoadingMovURL );
      }      
      if( SWFMatchPreloadMovieSize != "" && SWFMatchPreloadMovieSize != null )
      {
         fo.addVariable( "csScaleLoadingMov" , SWFMatchPreloadMovieSize );
      }
      
      if( args.movie )
      {
         fo.addVariable( "csFilesetBookmark", args.movie );
      }
      
      if( fo.write( elementId ) == false )
      {
         var node = '<div id="cs_noexpressUpdate">'
	               + '<p align="center">The Camtasia Studio video content presented here </p><p align="center"> requires JavaScript to be enabled and the latest version </p><p align="center">of the Macromedia Flash Player.  If you are you using </p><p align="center">a browser with JavaScript disabled please enable it now.</p><p align="center"> Otherwise, please update your version of the </p><p align="center">free Flash Player by <a href="http://www.macromedia.com/go/getflashplayer">downloading here</a>. </p>'
	               + '</div>'
         var n = (typeof elementId == 'string') ? document.getElementById( elementId ) : elementId;
         n.innerHTML = node;	               
      }
      
      return true;
   }