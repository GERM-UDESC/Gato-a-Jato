var args = new Object();
var query = location.search.substring(1);

// Get query string
var pairs = query.split( "," );

// Break at comma
for ( var i = 0; i < pairs.length; i++ )
{
   var pos = pairs[i].indexOf('=');
   if( pos == -1 ) 
   {   
      continue; // Look for "name=value"
   }

   var argname  = pairs[i].substring( 0, pos );  // If not found, skip
   var value    = pairs[i].substring( pos + 1 ); // Extract the name
   args[argname] = unescape( value );            // Extract the value
} 




function OnLoad()
{
	   vid = document.getElementById( "video1" );
   addEvent( vid, "click", divClickHandler );
	
		
}



   var toc1     = null;
   var toc2     = null;
   var vid      = null;
     
   //adds and event listener across major browser versions
   function addEvent( obj, type, fn )
   {
	   if ( obj.addEventListener )
	   {
		   obj.addEventListener( type, fn, true );
	   }
	   else if ( obj.attachEvent )
	   {
		   obj.attachEvent( "on" + type, fn );
	   }
	   else
	   {
		   obj["on" + type] = fn;
	   }
   }

   //removes event listeners across major browser versions
   function removeEvent( obj, type, fn )
   {
      if ( obj.removeEventListener )
	   {
	      obj.removeEventListener( type, fn, true );	
	   }
	   else if ( obj.detachEvent )
	   {
	     obj.detachEvent( "on" + type, fn );
	   }
	   else
	   {
		   delete obj["on" + type];	
	   }
   }
   
   function divClickHandler()
   {
      SwitchPlayer( 'video1', 'video2', '431', '500', '', '', '102 Basics Guide Reshoot_controller.swf', '102 Basics Guide Reshoot_config.xml', 'best', '8', 'FFFFFF', '102 Basics Guide Reshoot_preload.swf', '' );
      
      removeEvent( vid, 'click', divClickHandler );
   } 

